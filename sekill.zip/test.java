import java.util.*;

public class Main {
    static class Point {
        int x, y;
        Point(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            points[i] = new Point(scanner.nextInt(), scanner.nextInt());
        }
        scanner.close();

        // 根据x和y的正负性对点进行分类
        List<Point>[] posx = {new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>()};
        List<Point>[] posy = {new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>()};
        for (Point p : points) {
            int xSign = (p.x > 0) ? 1 : (p.x < 0) ? 2 : 3;
            int ySign = (p.y > 0) ? 1 : (p.y < 0) ? 2 : 3;
            posx[xSign].add(p);
            posy[ySign].add(p);
        }

        // 计算最大权值
        int maxScore = 0;
        for (int i = 0; i < 4; i++) {
            for (int j = i + 1; j < 4; j++) {
                maxScore += calculateScore(posx[i], posx[j]);
                maxScore += calculateScore(posy[i], posy[j]);
            }
        }

        System.out.println(maxScore);
    }

    private static int calculateScore(List<Point> list1, List<Point> list2) {
        if (list1.size() == 0 || list2.size() == 0) return 0;
        Collections.sort(list1, (a, b) -> Integer.compare(a.y, b.y));
        Collections.sort(list2, (a, b) -> Integer.compare(a.y, b.y));
        int score = 0;
        for (int i = 0; i < list1.size(); i++) {
            for (int j = 0; j < list2.size(); j++) {
                if (list1.get(i).x * list2.get(j).x < 0 || list1.get(i).y * list2.get(j).y < 0) {
                    score += 3; // 经过原点
                } else if (list1.get(i).x * list2.get(j).x > 0 && list1.get(i).y * list2.get(j).y > 0) {
                    score += 1; // 与x轴有交点
                } else {
                    score += 2; // 与y轴有交点
                }
            }
        }
        return score;
    }
}